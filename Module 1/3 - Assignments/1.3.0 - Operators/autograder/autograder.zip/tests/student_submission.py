# # Math Module Here # #

# how well do you know your operators?
# you can add each variable into the print function below
# to check you work, like so:
# print(first_number)

# multiply two factors of 64
first_number = None

# divide first_number by 10
second_number = None

# add second_number to first_number, then subtract 2
third_number = None

# now, using parentheses, divide second_number by 2, then multiply it by 20, and finally add 2.4
fourth_number = None

# think of two different ways to raise 8 to the 2nd power
# hint, for one of them you have to import a module discussed in class
squared_number_one = None
squared_number_two = None
